sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("cis.ik12.controller.App", {
        onInit() {
        }
      });
    }
  );
  