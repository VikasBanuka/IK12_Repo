/* global QUnit */

sap.ui.require(["cis/ik12/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
